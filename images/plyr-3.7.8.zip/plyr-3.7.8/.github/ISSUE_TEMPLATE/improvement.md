---
name: Improvement
about: Request a change that isn't a bug or new feature
---

<!--
Please describe the behaviour that you want to change, and why. Be as clear as possible to avoid confusion.

If you want to request multiple changes that aren't directly related, then create one issue per change.
-->
